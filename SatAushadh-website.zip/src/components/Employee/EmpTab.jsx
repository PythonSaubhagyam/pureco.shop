import { Box } from '@chakra-ui/react'

function EmpTab(){
  return (
       <>
       <Box>
        Tab
       </Box>
       </>
  )
}

export default EmpTab